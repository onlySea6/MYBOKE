# 关于我！

从事互联网前端行业，热爱学习的IT



# 关于本站

在这里记录我的学习笔记，并且尝试一些有趣的东西！

由VuePress强力驱动，reco主题

# Motto

The two things change your life is the people you meet and the book you read.

# 球球

<img src="" alt="公众号">
