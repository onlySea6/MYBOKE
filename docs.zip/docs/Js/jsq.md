---
title: 面试题
date: 2018-02-01
categories:
  - js
tags:
  - js
---
## 从浏览器地址栏输入url到显示页面的步骤(以HTTP为例)
- 地址[前端面试题](https://github.com/webSongNO1/FE-interview#%E5%89%8D%E7%AB%AF%E9%9C%80%E8%A6%81%E6%B3%A8%E6%84%8F%E5%93%AA%E4%BA%9Bseo)