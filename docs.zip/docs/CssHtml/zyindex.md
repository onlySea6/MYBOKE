---
title: API
date: 2018-10-30
sidebar: auto
categories:
  - index.html转译符
tags:
  - index.html转译符
---
## index.html转译符
- 网页上的图片不是自己打上去的 是转译上去的
- 常用的几个
- ![常用转译符](https://ftp.bmp.ovh/imgs/2021/04/dd42eda1b65288a3.png)

- [转译符大全](https://tool.oschina.net/commons?type=2) 

## 针对颜色 简写
- 双数为简写
  1. #cccccc = #ccc

## 网站上 少用img  多用背景图
- 这是一个提议  一个无法理解的伤痛

## 项目要经历考验 各种问题都要想到  要不上线的时候 老改bug
1. 比如一些名字  短的没问题 长的就不行

## input框选中 不会出现黑框 css 加这个属性
```css
 outline: none;
```
