---
title: ES6数组新增方法
date: 2018-09-24
categories:
 - ES6
tags:
 - ES6
---
## 数组新增方法详见js知识2