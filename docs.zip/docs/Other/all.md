---
title: web前端知识体系
date: 2020-09-24
categories:
 - 知识体系
tags:
 - 知识体系
---
## HTML
xhtml1.0
html5
## CSS
css2.0
css3.0
## JS
jQ
js
    es5
    es6
    es78
echart
three.js    
## 前端工程化
grunt
glup
jdf
fis3
webpack

## 模块化
seajs
require.js
common.js
es6

## 前端模块引擎
handlebars

## MVVM
Vue
低
中
高
Ng
1.7
2-
React
ember

## 服务端
node
express
egg.js
php
java
go
py

## 服务器
linux
centos
nginx

## Other
SEO
用户体检
性能优化

## 多端
### PC
用户端 c
后台端（商家端）b端
## H5/m/移动端
纯M
微信公众号
微信中的分享
App中的网页
    webview
## 小程序
微信小程序
支付宝小程序
快应用
轻应用
## APP
React Native Rn
Flutter
iconic
weex