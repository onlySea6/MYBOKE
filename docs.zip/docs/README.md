---

# 默认主题

home: true
# bgImage: 'https://upfile2.asqql.com/upfile/2009pasdfasdfic2009s305985-ts/gif_spic/2019-6/20196720544437762.gif'

# heroText: null #标题不显示

# 主页图片地址

# heroImage: /javascript.gif

# 背景图片

# //yarn deploy 打包

---

# 文章链接

<!-- - [我的博客地址](http://www.baidu.com/) -->

- [Markdown 语法整理](https://www.jianshu.com/p/b03a8d7b1719)
