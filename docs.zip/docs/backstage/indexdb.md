---
title: 本地存储
date: 2019-12-30
sidebar: auto
categories:
  - indexdb
tags:
  - indexdb
---
## 本地存储之 indexdb
### 优点
- 容量大硬盘的三分之一
- 异步执行
- 兼容好
### 缺点
- 不好写

### 所有的操作都是异步的 
- 有一个版本概念