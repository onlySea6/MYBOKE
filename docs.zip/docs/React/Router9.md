---
title: 静态路线
date: 2019-10-01
categories:
  - react
tags:
  - react
---

## 静态路线

以前版本的React Router使用静态路由来配置应用程序的路由。这样可以在渲染之前检查和匹配路线。由于v4转移到动态组件而不是路由配置，因此一些以前的用例变得不那么明显和棘手。

我们正在开发一个用于静态路由配置和React Router的软件包，以继续满足这些用例。现在正在开发中，但我们希望您能尝试一下并提供帮助。

[反应路由器配置](https://github.com/reacttraining/react-router/tree/master/packages/react-router-config)
